<?php
    $string['title'] = 'Комментарии';
?>